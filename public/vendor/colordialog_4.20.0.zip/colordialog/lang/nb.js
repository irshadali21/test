/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'nb', {
	clear: 'Nullstill',
	highlight: 'Fremhevet',
	options: 'Alternativer for farge',
	selected: 'Valgt farge',
	title: 'Velg farge'
} );
